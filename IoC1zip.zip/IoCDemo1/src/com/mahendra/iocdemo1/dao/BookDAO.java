package com.mahendra.iocdemo1.dao;

public class BookDAO {

	public BookDAO() {
		super();
		System.out.println("Instance of BookDAO created!");
	}

	
}
