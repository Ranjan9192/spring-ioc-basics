package com.mahendra.springbasics;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import org.hibernate.context.spi.CurrentTenantIdentifierResolver;
import org.springframework.beans.factory.annotation.Autowired;

public class MyResolver implements CurrentTenantIdentifierResolver {
	
	@Autowired
	private HttpSession session;
	
	public void setSession(HttpSession session) {
		this.session = session;
	}

	@Override
	public String resolveCurrentTenantIdentifier() {
		String tenantId = getTenantId();
		System.out.println("Tenant resolved : "+tenantId);
		return tenantId;
	}

	@Override
	public boolean validateExistingCurrentSessions() {
		return false;
	}

	public String getTenantId() {
		String tenantId = (String) session.getAttribute("tenant");
		if(tenantId == null || tenantId.trim().length() ==0){
			System.out.println("No tenant id present in session!");
			tenantId="tenant_1";
		}
		return tenantId;
		
	}


}
