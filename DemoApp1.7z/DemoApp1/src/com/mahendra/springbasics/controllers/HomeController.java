package com.mahendra.springbasics.controllers;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.mahendra.springbasics.models.Book;
import com.mahendra.springbasics.service.LibraryService;

@Controller
public class HomeController {
@Autowired
private LibraryService service;

	@RequestMapping("/home.do")
	public String goHome(Model map,HttpSession session,@RequestParam("id")String id){
		//service.saveBook(new Book("Let us C++", "Yashwant Kanetkar", "Learn C++"));
		session.setAttribute("tenant", id);
		map.addAttribute("books", service.getAllBooks() );
		return "home";
	}
}
