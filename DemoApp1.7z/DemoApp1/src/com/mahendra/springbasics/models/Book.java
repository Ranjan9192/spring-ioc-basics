package com.mahendra.springbasics.models;

import java.io.Serializable;

import javax.persistence.*;

@Entity @Table(name="books")
public class Book implements Serializable {
	@Id
	@Column(name="id")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Short id;
	private String title, author;
	@Column(name="descrpt")	
	private String description;
	
	public Book() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Book( String title, String author, String description) {
		super();
		this.title = title;
		this.author = author;
		this.description = description;
	}
	
	public void setBookId(Short id){
		this.id = id;		
	}
	
	public Short getBookId() {
		return id;
	}
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
}
