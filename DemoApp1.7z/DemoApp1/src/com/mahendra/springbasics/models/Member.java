package com.mahendra.springbasics.models;

import java.io.Serializable;

import javax.persistence.*;

@Entity @Table(name="members")
public class Member implements Serializable {
	@Id
	@Column(name="id")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Short id;
	
	private String firstName, lastName, contact;
	
public void setMemberId(Short id){
	this.id = id;
}
public Short getMemberId() {
	return id;
}


public Member( String firstName, String lastName, String contact) {
	super();
	this.firstName = firstName;
	this.lastName = lastName;
	this.contact = contact;
}

public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public String getContact() {
	return contact;
}
public void setContact(String contact) {
	this.contact = contact;
}
public Member() {
	super();
	// TODO Auto-generated constructor stub
}

}
