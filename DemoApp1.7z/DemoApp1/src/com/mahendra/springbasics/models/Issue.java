package com.mahendra.springbasics.models;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;

@Entity @Table(name="issues")
public class Issue implements Serializable {
	@Id
	@Column(name="id")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Short id;
	@Column(name="issue_date")
	@Temporal(TemporalType.DATE)
	private Date issueDate;
	@ManyToOne
	@JoinColumn(name="memberId")
	private Member issuedTo;
	@ManyToOne
	@JoinColumn(name="bookId")
	private Book book;
	private boolean pending;
	

	public void setIssueId(Short id){
		this.id = id;
	}
	
	public Short getIssueId() {
		return id;
	}
	public Date getIssueDate() {
		return issueDate;
	}
	
	public void setIssueDate(Date issueDate) {
		this.issueDate = issueDate;
	}
	
	public Member getIssuedTo() {
		return issuedTo;
	}
	
	
	public void setIssuedTo(Member issuedTo) {
		this.issuedTo = issuedTo;
	}
	
	public Book getBook() {
		return book;
	}
	
	
	public void setBook(Book book) {
		this.book = book;
	}
	public boolean isPending() {
		return pending;
	}
	
	public void setPending(boolean pending) {
		this.pending = pending;
	}
	public Issue() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Issue( Member issuedTo, Book book) {
		super();
	
		this.issueDate = new Date();
		this.issuedTo = issuedTo;
		this.book = book;
		this.pending = true;
	}
	
}
