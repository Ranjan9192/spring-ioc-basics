package com.mahendra.springbasics.dao;

import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.hibernate.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mahendra.springbasics.models.Book;

@Repository
public class BookRepository {
	//private SortedSet<Book> books = new TreeSet<Book>();
	@Autowired
	private SessionFactory factory;
	
	public Book add(String title, String author, String description){
		Book book = new Book(title, author, description);
		Session session = factory.getCurrentSession();
		session.save(book);

		return book;
	}
	
	public Book findById(short id){
		Book b = null;
		Session session = factory.getCurrentSession();
		b = (Book) session.get(Book.class, id);
		return b;
	}
	
	public Set<Book> searchByTitle(String title){
		Set<Book> temp = null;
		Session session = factory.getCurrentSession();
		temp = new TreeSet<Book>(session.createQuery("from Book b where lower(b.title) = ?").setString(1, title.trim().toLowerCase()).list());
		return temp;
	}
	
	public Set<Book> searchByDescription(String description){
		Set<Book> temp = new TreeSet<Book>();
		Session session = factory.getCurrentSession();
		temp = new TreeSet<Book>(session.createQuery("from Book b where lower(b.description) = ?").setString(1, description.trim().toLowerCase()).list());
		
		return temp;
	}
	
	public Set<Book> searchByAuthor(String author){
		Set<Book> temp = new TreeSet<Book>();
		Session session = factory.getCurrentSession();
		temp = new TreeSet<Book>(session.createQuery("from Book b where lower(b.author) = ?").setString(1, author.trim().toLowerCase()).list());
		
		return temp;
	}
	
	public List<Book> getAll(){
		List<Book> temp = new LinkedList<Book>();
		Session session = factory.getCurrentSession();
		temp = session.createQuery("from Book b").list();
		return temp;
	}


	public void setFactory(SessionFactory factory) {
		this.factory = factory;
	}
}
