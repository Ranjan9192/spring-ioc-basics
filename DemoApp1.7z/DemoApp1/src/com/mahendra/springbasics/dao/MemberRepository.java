package com.mahendra.springbasics.dao;

import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mahendra.springbasics.models.Member;

@Repository
public class MemberRepository {
	//private SortedSet<Member> members = new TreeSet<Member>();
	
	@Autowired
	private SessionFactory factory;
	
	public void setFactory(SessionFactory factory) {
		this.factory = factory;
	}

	public Member add(String firstName, String lastName, String contact){		
		Member member = new Member(firstName,lastName,contact);
		Session session = factory.getCurrentSession();
		session.save(member);
		return member;
	}
	
	public Member findById(short id){
		Member m = null;
		Session session = factory.getCurrentSession();
		m = (Member) session.get(Member.class, id);
		return m;
	}
	
	public Set<Member> searchByFirstName(String firstName){
		Set<Member> temp = null;
		Session session = factory.getCurrentSession();
		temp = new TreeSet<Member>(
				session.createQuery("from Member m where lower(m.firstName) = ?")
				.setString(1,firstName.trim().toLowerCase())
				.list()
				);
		
		return temp;
	}
	
	public Set<Member> searchByLastName(String lastName){
		Set<Member> temp = null;
		Session session = factory.getCurrentSession();
		temp = new TreeSet<Member>(
				session.createQuery("from Member m where lower(m.lastName) = ?")
				.setString(1,lastName.trim().toLowerCase())
				.list()
				);
		
		return temp;
	}
	
	public List<Member> getAll(){
		Session session = factory.getCurrentSession();
		
		return session.createQuery("from Member m").list(); 
	}
}
