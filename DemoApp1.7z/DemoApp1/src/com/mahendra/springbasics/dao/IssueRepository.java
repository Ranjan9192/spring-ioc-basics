package com.mahendra.springbasics.dao;

import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mahendra.springbasics.models.*;

@Repository
public class IssueRepository {
	//private SortedSet<Issue> issues = new TreeSet<Issue>();
	
	@Autowired
	private SessionFactory factory;
	
	public Issue add(Book book, Member member){
		Issue issue = new Issue( member,book);
		Session session = factory.getCurrentSession();
		session.save(issue);
		return issue;
	}
	
	public Issue findById(short id){
		Issue issue = null;
		Session session = factory.getCurrentSession();
		issue = (Issue) session.get(Issue.class, id);
		return issue;
	}
	public boolean isBookAvailable(short bookId){		
		Session session = factory.getCurrentSession();
		int n = session.createQuery("from Issue i where i.book.bookId = ? and i.pending = true")
					.setShort(1,bookId).list().size();
		if(n<1)
			return true;
		return false;
	}
	
	public boolean isMemberAvailable(short memberId){
		Session session = factory.getCurrentSession();
		int n = session.createQuery("from Issue i where i.member.memberId = ? and i.pending = true").
				setShort(1, memberId).list().size();
		if(n<1)
			return true;
		return false;
	}
	
	public List<Issue> getAllPending(){
		List<Issue> temp = new LinkedList<Issue>();
		Session session = factory.getCurrentSession();
		return temp;
	}
	
	public void setFactory(SessionFactory factory) {
		this.factory = factory;
	}

	public List<Issue> getAllReturned(){
		List<Issue> temp = new LinkedList<Issue>();
		Session session = factory.getCurrentSession();
		temp = session.createQuery("from Issue i where i.pending = false").list();
		return temp;
	}
	
	public List<Issue> getAll(){
		List<Issue> temp = new LinkedList<Issue>();
		Session session = factory.getCurrentSession();
		temp = session.createQuery("from Issue i").list();
		return temp;
	}
}
