package com.mahendra.springbasics;

import javax.sql.DataSource;

import org.hibernate.engine.jdbc.connections.spi.AbstractDataSourceBasedMultiTenantConnectionProviderImpl;

public class MyConnectionProvider extends AbstractDataSourceBasedMultiTenantConnectionProviderImpl {
	private DataSource db1;
	private DataSource db2;
	
	public void setDb1(DataSource db1) {
		this.db1 = db1;
	}

	public void setDb2(DataSource db2) {
		this.db2 = db2;
	}

	@Override
	protected DataSource selectAnyDataSource() {
		return db1;
		
	}

	@Override
	protected DataSource selectDataSource(String tenantIdentifier) {
		if(tenantIdentifier.equalsIgnoreCase("tenant_2"))
			return db2;
		else
			return db1;
	}

	/*@Override
	protected ConnectionProvider getAnyConnectionProvider() {
		// TODO Auto-generated method stub
		return cp1;
	}

	@Override
	protected ConnectionProvider selectConnectionProvider(String arg0) {
		if(arg0.equalsIgnoreCase("tenant_1"))
			return cp1;
		else if(arg0.equalsIgnoreCase("tenant_2"))
			return cp2;
		return getAnyConnectionProvider();
	}*/

}
